# Mediator
class ChatMediator
  def initialize
    @users = []
  end

  def add_user(user)
    @users << user
    user.mediator = self
  end

  def send_message(message, sender)
    @users.each do |user|
      next if user == sender

      user.receive_message(message)
    end
  end
end

# Colleague
class User
  attr_accessor :mediator, :name

  def initialize(name)
    @name = name
    @mediator = nil
  end

  def send_message(message)
    puts "#{@name} sends message: #{message}"
    @mediator.send_message(message, self)
  end

  def receive_message(message)
    puts "#{@name} receives message: #{message}"
  end
end

# Використання паттерну Mediator
mediator = ChatMediator.new

user1 = User.new("User 1")
user2 = User.new("User 2")
user3 = User.new("User 3")

mediator.add_user(user1)
mediator.add_user(user2)
mediator.add_user(user3)

user1.send_message("Hello, everyone!")
user2.send_message("Hi there!")
